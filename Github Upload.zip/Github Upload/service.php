<!DOCTYPE html>
<html>
    
    <head>
        <meta charset="utf-8">
        <title>Hella Vapes: Contact</title>
        <meta name="description" content="Contact Page for Hella Vapes">
        <link rel="stylesheet" href="CSS/hella.css">

    </head>
    <body>
    
    <nav id="top-nav">
        <a href="#">Login/Logout</a> 
        <a href="#">My Account</a> 
        <a href="#">Cart</a> 
    </nav>
    
    <header><div id="page-header-image"><img src="images/contactheader2.png" alt=" Contact Header" id="page-header"></div></header>
    
    <nav id="main-nav">
        <a href="index.html">Home</a> |
          <div class="dropdown">
               <button class="dropbtn"><a href="juice.html">Shop Juice</a></button> |
                <div class="dropdown-content">
                    <a href="freebase.html">Free-Base Juice</a>
                    <a href="saltnic.html">Salt-Nic Juice</a>
                </div>
            </div> 
           <div class="dropdown">
               <button class="dropbtn"><a href="hardware.html">Shop Hardware</a></button> |
                <div class="dropdown-content">
                    <a href="sub-ohm.html">Sub-Ohm Kits</a>
                    <a href="all-in-one.html">All-In-One Kits</a>
                    <a href="mods.html">Mods</a>
                    <a href="tanks.html">Tanks</a>
                    <a href="coils.html">Coils</a>
                    <a href="parts.html">Parts</a>
                </div>
            </div> 
        <a href="service.php">Customer Service</a>
    </nav>
       
       <?php
        if(isset($_POST['submit'])){
        $recipient = "cgarc524@gmail.com";
        $subject = $_POST["ctopic"];
        $senderemail = $_POST["cemail"];
        $cfname = $_POST["cfname"];
        $clname = $_POST["clname"];
        $ccid = $_POST["ccid"];
        $cmessage = $_POST["cmessage"];
        
        $mailBody="First Name: $cfname\n <br>
                   Last Name: $clname\n <br>
                   Email: $senderEmail\n <br>
                   Customer ID: $ccid\n <br>
                   \n$message";
                   
        mail($recipient, $subject, $mailBody, "From: $senderemail <$senderEmail>");
    
        $thankyou = "<p>Thank you for your message " .$cfname. ", Hella Vapes will respond shortly.</p>";
            
        }

        ?>
        
    <div id="content">
        <h1>Customer Service</h1>
        
        <?=$thankyou?>
        
        <form id="contact" method="post" action="service.php">
            <label for="cfname">First Name</label><br>
            <input type="text" name="cfname" id="cfname" required><br>
            
            <label for="clname">Last Name</label><br>
            <input type="text" name="clname" id="clname" required><br>
            
            <label for="cemail">Email</label><br>
            <input type="email" name="cemail" id="cemail" required><br>
            
            <label for="ccog">Entering your customer ID will speed up the process of our response.</label><br>
            
            <input onclick="document.getElementById('custom').disabled = false; document.getElementById('charstype').disabled = true;" type="radio" name="type" checked="checked">Returning Customer
            <input type="text" name="custom" id="custom" placeholder="Enter customer ID" required>

            <input onclick="document.getElementById('custom').disabled = true; document.getElementById('charstype').disabled = false;" type="radio" name="type" value="customurl">Guest<br>
            
            <label for="ctopic">Topic</label><br>
              <select name="ctopic" id="ctopic" required>
                    <option value="">Select...</option>
                    <option value="account">Account</option>
                    <option value="orders">Orders</option>
                    <option value="device_help">Device Help</option>
                    <option value="other">Other</option>
              </select><br>
              
              <label for="cmessage">Message</label><br>
              <textarea name="cmessage" id="cmessage" form="contact" placeholder="Enter message here..." required></textarea><br>
              
              <input type="submit" id="submit" value="Send Message">
        
        </form>
        
    </div>
        
        <footer><p id="dev-tag">Created by <a href="https://garciadevelop.com/" target="_blank">Garcia Develop</a></p>
                <p id="copywrite">Copyright © 2019 · All Rights Reserved · Hella Vapes</p>
        </footer>
        
        <script src="js/hella.js"></script>
        <script src="js/jquery-ui-1.12.1.custom"></script>
        
    </body>
</html>